(function () {
  function startEmbeddedLanServer() {
    if (!window.nodejs || window.__mecchaLanBootStarted) return;
    window.__mecchaLanBootStarted = true;
    window.nodejs.start('main.js', function (error) {
      if (error) {
        console.error('[Meccha] LAN server failed to start:', error);
        window.dispatchEvent(new CustomEvent('mc_lan_server_error', { detail: String(error) }));
      } else {
        console.info('[Meccha] Embedded LAN server runtime started');
      }
    });
  }
  document.addEventListener('deviceready', startEmbeddedLanServer, false);
})();
