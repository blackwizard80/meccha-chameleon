'use strict';

// Runs inside the embedded Node.js runtime on Android.
// Every installed phone runs its own local LAN server so it can discover rooms
// and the host phone can keep the room authoritative without an internet server.
process.env.NODE_ENV = 'production';
process.env.PORT = '3000';
require('./server.bundle.js');
