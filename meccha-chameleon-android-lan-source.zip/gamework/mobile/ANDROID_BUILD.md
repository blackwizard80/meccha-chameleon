# Android APK build (offline LAN)

This project keeps the existing React/Three.js game and packages it as a Cordova Android app. The app starts an embedded Node.js LAN server on each phone; the host phone creates the authoritative room on its own server at port 3000, while other phones join that host's Wi-Fi/Hotspot IP.

## Build with GitHub Actions

1. Push the complete project to a GitHub repository on the `main` or `master` branch.
2. Open **Actions** and select **Build Android APK**.
3. Run the workflow with **Run workflow** (or push a commit to trigger it).
4. When the workflow finishes, download the `meccha-chameleon-android-debug` artifact. It contains `app-debug.apk`.

## LAN use

- Start a Wi-Fi hotspot on the host phone.
- Connect the other phones to that hotspot.
- Open the game on every phone. Each install starts its local LAN service.
- On the host phone, create a room. Other players join the discovered room or enter the host IP shown by the host phone.
- Internet access is not required after the APK is installed.

## Important test status

This is an Android packaging and embedded-server integration pass, not a claim that multiplayer has already been field-tested. The first APK must be tested on at least two physical Android phones. In particular, Android hotspot UDP room discovery can vary by device/network; direct host-IP joining is retained as a fallback. Keep the app open while hosting during this first test.
